package com.sondv.phone.validation;

public class ValidationGroup {
    public interface Register {}
}
