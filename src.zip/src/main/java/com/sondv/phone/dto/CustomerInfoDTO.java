package com.sondv.phone.dto;

import lombok.Data;

@Data
public class CustomerInfoDTO {
    private String fullName;
    private String email;
}
