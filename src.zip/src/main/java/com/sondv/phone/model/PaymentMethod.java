package com.sondv.phone.model;

public enum PaymentMethod {
    COD, VNPAY, MOMO
}
