package com.sondv.phone.model;

public enum RoleName {
    ADMIN, CUSTOMER, STAFF
}

