package com.sondv.phone.model;

public enum AuthProvider {
    LOCAL,
    GOOGLE,
    FACEBOOK
}